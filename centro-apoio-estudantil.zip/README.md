# Centro de Apoio Estudantil Online

Este repositório contém o site oficial do Centro de Apoio Estudantil Online.

## Arquivos

- index.html → Código do site
- logo.png → Logotipo da empresa

## Instruções para hospedar no GitHub Pages

1. Crie um repositório no GitHub e envie todos os arquivos.  
2. Vá em **Settings → Pages**, selecione **Branch: main** e pasta **root**.  
3. Clique em **Save**.  
4. O site estará disponível em `https://seunome.github.io/nome-do-repositorio/`
